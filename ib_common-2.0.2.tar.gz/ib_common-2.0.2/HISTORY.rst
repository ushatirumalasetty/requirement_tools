.. :changelog:

History
-------

0.1.68 (2019-05-07)
+++++++++++++++++++

* Added support for file response object


0.1.67 (2019-05-06)
+++++++++++++++++++

* added timezone deactivate in process_response for datetime middleware

0.1.66 (2019-03-20)
+++++++++++++++++++

* Added keystore_v2 which doesn't involve django settings for pushing and fetching from s3

0.1.65 (2019-03-09)
+++++++++++++++++++

* added new datetime util to convert utc string to local datetime


0.1.64 (2018-12-24)
+++++++++++++++++++

* Updated custom logger formatter

0.1.63 (2018-12-22)
+++++++++++++++++++
* Added db state check cron job

0.1.62 (2018-12-20)
+++++++++++++++++++
* Removed redis db backend in KeyStore

0.1.61 (2018-12-20)
+++++++++++++++++++
* Update bug fixed for KeyStore


0.1.60 (2018-12-17)
+++++++++++++++++++
* Added zappa sentry exception handler related utils

0.1.59 (2018-12-17)
+++++++++++++++++++
* Added log api middleware related utils


0.1.58 (2018-12-15)
+++++++++++++++++++
* Doc strings updated for stores and name spacing updated

0.1.57 (2018-11-21)
+++++++++++++++++++
* Added map_sort in custom queryset
* Added KeyStore


0.1.56 (2018-08-06)
+++++++++++++++++++

* added common validators

0.1.55 (2018-07-20)
+++++++++++++++++++

* added additional language enums

0.1.54 (2018-05-30)
+++++++++++++++++++

* added kannada language choice

0.1.53 (2018-04-02)
+++++++++++++++++++

* bug fix in log api middleware

0.1.52 (2018-03-14)
+++++++++++++++++++

* added date time middleware

0.1.51 (2018-03-13)
+++++++++++++++++++

* updated date_time_utils to support multiple time_zones,
deprecated old methods

0.1.49 (2018-02-28)
+++++++++++++++++++

* bug fix in log api middleware

0.1.49 (2018-02-16)
+++++++++++++++++++

* ADDED exception logging for log api middleware

0.1.48 (2018-02-15)
+++++++++++++++++++

* fixed typo in log api middleware

0.1.47 (2018-02-15)
+++++++++++++++++++

* added custom logger log api middleware

0.1.46 (2018-02-03)
+++++++++++++++++++

* added functions 'get_random_number_from_gd', 'publish_message_to_topic'

0.1.45 (2018-02-01)
+++++++++++++++++++

* Replaced full_clean with custom_full_clean method inorder skip ForeignKey
default check by django (which increases a db hit) and unique constraint checks

0.1.44 (2018-01-26)
+++++++++++++++++++

* bug fix in interface_utils

0.1.43 (2018-01-06)
+++++++++++++++++++

* bug fix for signal callback_wrapper

0.1.42 (2018-01-06)
+++++++++++++++++++

* python 2 - 3 compatibility

0.1.41 (2018-01-02)
+++++++++++++++++++

* added get list of names method in base enum class

0.1.40 (2017-12-29)
+++++++++++++++++++

* updated requirements

0.1.39 (2017-12-16)
+++++++++++++++++++

* added missing comma in __init__

0.1.38 (2017-12-02)
+++++++++++++++++++

* added update objects bulk method to abstract date time