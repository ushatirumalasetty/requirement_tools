import logging

LOGGER = logging.getLogger(__name__)


def check_db_state():
    for i in range(5):
        from django_swagger_utils.models import Latency
        LOGGER.info(
            "Total Latencies as of now: {}".format(
                Latency.objects.all().count()))

        from django.contrib.auth import get_user_model
        LOGGER.info("Total No of users as of now: {}".format(
            get_user_model().objects.all().count()))
