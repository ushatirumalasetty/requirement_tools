from django.db.models import Manager

__author__ = 'vedavidh'


class CommonCustomManager(Manager):

    def get_queryset(self):
        from .common_custom_queryset import CommonCustomQuerySet
        return CommonCustomQuerySet(self.model, using=self._db)
