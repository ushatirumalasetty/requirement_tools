from django.db.models import QuerySet

__author__ = 'vedavidh'


class CommonCustomQuerySet(QuerySet):

    def bulk_create(self, objs, batch_size=None):
        if not objs:
            return objs
        for obj in objs:
            obj.custom_full_clean()
        super(CommonCustomQuerySet, self).bulk_create(objs=objs,
                                                      batch_size=batch_size)

    def map_sort(self, id_weight_map, sort_by='id'):

        clone = self._clone()

        if not id_weight_map:
            return clone

        field_name = sort_by

        if sort_by[0] == '-':
            field_name = sort_by[1:]

        clauses = ' '.join([
            'WHEN %s=%s THEN %s' % (field_name, id_, weight) for id_, weight in
            list(id_weight_map.items())])
        ordering = 'CASE %s END' % clauses

        if sort_by[0] == '-':
            base_query = clone.extra(
                select={'ordering': ordering}, order_by=('-ordering',)
            )
        else:
            base_query = clone.extra(
                select={'ordering': ordering}, order_by=('ordering',)
            )

        return base_query
