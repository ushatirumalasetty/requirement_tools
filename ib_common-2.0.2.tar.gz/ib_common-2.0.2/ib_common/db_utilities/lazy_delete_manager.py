"""
Created on 24/10/17

@author: revanth
"""
from ib_common.db_utilities import CommonCustomManager


class LazyDeleteManager(CommonCustomManager):

    def get_queryset(self):
        return super(LazyDeleteManager, self).get_queryset().filter(
            is_deleted=False)
