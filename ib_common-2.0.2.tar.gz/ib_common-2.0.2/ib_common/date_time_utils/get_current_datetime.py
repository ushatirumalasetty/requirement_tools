__author__ = 'vedavidh'
from deprecated import deprecated


@deprecated(
    'This method is deprecated. Use get_current_local_datetime instead')
def get_current_datetime():
    import datetime
    from django.utils.timezone import utc

    now = datetime.datetime.utcnow().replace(tzinfo=utc)

    return now
