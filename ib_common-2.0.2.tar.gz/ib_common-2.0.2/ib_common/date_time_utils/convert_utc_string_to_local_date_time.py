"""
Created on 2019-03-09

@author: revanth
"""


def convert_utc_string_to_local_date_time(
        string, format_="%b %d, %Y at %I:%M%p"):
    """
        Default Datetime format : 'Aug 09, 2015 at 11:09PM'
    """
    from datetime import datetime

    try:
        datetime_object = datetime.strptime(string, format_)
    except:
        return None

    from django.conf import settings
    use_tz = getattr(settings, 'USE_TZ', False)
    if use_tz:
        from django.utils import timezone
        import pytz
        datetime_object = pytz.utc.localize(datetime_object)

        datetime_object = datetime_object.astimezone(
            timezone.get_current_timezone())

    return datetime_object
