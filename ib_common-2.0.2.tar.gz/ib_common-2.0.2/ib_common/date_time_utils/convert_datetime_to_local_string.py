__author__ = 'vedavidh'


def convert_datetime_to_local_string(obj, format_="%b %d, %Y at %I:%M%p"):
    from django.utils import timezone
    try:
        if timezone.is_naive(obj):
            obj = timezone.make_aware(obj)
        obj = timezone.localtime(obj)
        return obj.strftime(format=format_)
    except:
        return None
