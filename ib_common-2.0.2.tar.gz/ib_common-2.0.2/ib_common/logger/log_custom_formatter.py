import json

import logging

LOGGER = logging.getLogger('')


class LogCustomFormatter(logging.Formatter):
    """
    custom log formatter

    settings.py

    from ib_common.logger.log_custom_formatter import LogCustomFormatter
    LOGGING['formatters'].update({
        'le_console': {
            '()': LogCustomFormatter,
        }
    })

    """

    def format(self, record):
        # to remove fields from log record
        to_remove = ["module", "filename", "processName",
                     "thread", "threadName", "relativeCreated", "msecs",
                     "process", "levelno", "stage", "created", "exc_info",
                     "asctime", "exc_text", ]
        from copy import deepcopy
        new_record = deepcopy(record)
        for key in to_remove:
            try:
                new_record.__dict__.pop(key)
            except KeyError:
                pass

        # log message
        message = new_record.getMessage()
        try:
            message = json.loads(message)
        except (TypeError, ValueError):
            pass
        new_record.message = message
        new_record.__dict__["message"] = message

        metadata_keys = ["funcName", "name", "pathname", "lineno", "levelname"]
        metadata_values = []
        for key in metadata_keys:
            value = new_record.__dict__.pop(key, "")
            if not value:
                value = ""
            metadata_values.append(str(value))
        new_record.__dict__['metadata'] = " - ".join(metadata_values)
        new_record.__dict__.pop("msg")
        new_record.__dict__.pop("args", "")
        try:
            return json.dumps(new_record.__dict__)
        except TypeError:
            data_dict = new_record.__dict__
            return json.dumps(self.convert_to_json_convertable_dict(data_dict))

    @staticmethod
    def convert_to_json_convertable_dict(data):
        # TODO: Handling all cases instead of logging error
        new_dict = dict()
        for data_key, data_value in data.items():
            try:
                _ = json.dumps(data_value)
            except TypeError:
                try:
                    data_value = str(data_value)
                except Exception as err:
                    LOGGER.error(str(err))
                    continue
            new_dict[data_key] = data_value

        return new_dict
