import logging


class CustomHandler(logging.Handler):
    def __init__(self):
        logging.Handler.__init__(self)

    def emit(self, record):
        """ Emit overrides the abstract logging.Handler logRecord emit method

        records the log

        :param record: A class of type ```logging.LogRecord```
        :return: None
        """

        print(record.__dict__)
