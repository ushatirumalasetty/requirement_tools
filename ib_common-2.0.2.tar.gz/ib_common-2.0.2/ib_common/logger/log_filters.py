import logging
import os

from ib_common import local

"""
    this is a custom log filters

    usage:

    settings.py

    LOGGING['filters'].update({
        'user_id': {
            '()': 'ib_common.logger.log_filters.UserIDFilter'
        },
        'path_info': {
            '()': 'ib_common.logger.log_filters.PathInfoFilter'
        },
        'aws_request_id': {
            '()': 'ib_common.logger.log_filters.AWSRequestIdFilter'
        },
        'stage': {
            '()': 'ib_common.logger.log_filters.StageFilter'
        }
    })


    
"""

class UserIDFilter(logging.Filter):

    def filter(self, record):
        record.user_id = getattr(local, 'user_id', 'GUEST')
        return True


class PathInfoFilter(logging.Filter):

    def filter(self, record):
        record.path_info = getattr(local, 'path_info', '/')
        return True


class AWSRequestIdFilter(logging.Filter):

    def filter(self, record):
        record.aws_request_id = getattr(local, 'aws_request_id', '')
        return True


class StageFilter(logging.Filter):

    def filter(self, record):
        record.stage = os.environ.get("STAGE", "local")
        return True
