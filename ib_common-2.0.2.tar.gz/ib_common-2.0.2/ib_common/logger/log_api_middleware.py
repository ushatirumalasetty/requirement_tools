# from django
import json
import logging
from functools import reduce
from operator import add
from time import time

from django.db import connection
from django.utils.deprecation import MiddlewareMixin

logger_200 = logging.getLogger('LogAPI200')
logger_non_200 = logging.getLogger('LogAPINON200')
logger_non_api = logging.getLogger('LogNONAPI')

from deprecated import deprecated


@deprecated('This class is deprecated')
class LogAPIMiddleware(MiddlewareMixin):
    """
    this is a custom middleware, which will log some info about API

    usage:

    settings.py

    LOGGING['handlers'].update(
        {
            'logentries': {
            'level': 'DEBUG',
            'token': os.environ.get('LE_TOKEN', ''),
            'class': 'logentries.LogentriesHandler',
            'formatter': 'le_console',
            "filters": ["request_id", "user_id", "path_info",
                        "aws_request_id", "stage"],
        },
        'logentries_200': {
            'level': 'DEBUG',
            'token': os.environ.get('LE_200_TOKEN', ''),
            'class': 'logentries.LogentriesHandler',
            'formatter': 'le_console',
            "filters": ["request_id", "user_id", "path_info",
                        "aws_request_id", "stage"],
        },
        'logentries_non_200': {
            'level': 'DEBUG',
            'token': os.environ.get('LE_NON_200_TOKEN', ''),
            'class': 'logentries.LogentriesHandler',
            'formatter': 'le_console',
            "filters": ["request_id", "user_id", "path_info",
                        "aws_request_id", "stage"],
        },
        'logentries_non_api': {
            'level': 'DEBUG',
            'token': os.environ.get('LE_NON_API_TOKEN', ''),
            'class': 'logentries.LogentriesHandler',
            'formatter': 'le_console',
            "filters": ["request_id", "user_id", "path_info",
                        "aws_request_id", "stage"],
        },
        }
    )

    LOGGING['loggers'].update({
        'LogAPI200': {
            'handlers': ['logentries_200', 'sentry', ],
            'level': 'DEBUG',
            'propagate': False,
        },
        'LogAPINON200': {
            'handlers': ['logentries_non_200', 'sentry', ],
            'level': 'DEBUG',
            'propagate': False,
        },
        'LogNONAPI': {
            'handlers': ['logentries_non_api', 'sentry', ],
            'level': 'DEBUG',
            'propagate': False,
        },
    })

    MIDDLEWARE.append('ib_common.logger.log_api_middleware.LogAPIMiddleware')



    """

    def _get_request(self, request):

        request_keys = ['LANGUAGE_CODE', 'method', 'content_params',
                        'path_info', 'path', 'COOKIES']
        request_info = {}
        for each in request_keys:
            request_info[each] = getattr(request, each, '')
        if 'auth' in request.__dict__:
            request_info['auth'] = str(request.auth)

        meta_keys = [
            'HTTP_AUTHORIZATION',
            'HTTP_REFERER',
            'SERVER_SOFTWARE',
            'UPSTART_EVENTS',
            'SCRIPT_NAME',
            'CONTENT_LENGTH',
            'HTTP_ORIGIN',
            'SERVER_PROTOCOL',
            'HTTP_COOKIE',
            'PATH_INFO',
            'UPSTART_INSTANCE',
            'HTTP_AUTHORITY',
            'HTTP_CACHE_CONTROL',
            'HTTP_HOST',
            'HTTP_ACCEPT',
            'SERVER_NAME',
            'HTTP_ACCEPT_LANGUAGE',
            'REQUEST_METHOD',
            'LANGUAGE',
            'HTTP_USER_AGENT',
            'LANG',
            'HTTP_CONNECTION',
            'HTTP_X_SOURCE',
            'REMOTE_ADDR',
            'CONTENT_TYPE',
            'TZ',
            'REMOTE_HOST',
            'HTTP_ACCEPT_ENCODING'
        ]

        request_meta_info = {}
        for each_key in meta_keys:
            if each_key in request.META:
                request_meta_info[each_key] = request.META[each_key]

        request_user = {}
        if request.user is not None:
            pop_fields = ['_state', '_password', 'password', '_setupfunc',
                          '_wrapped']
            from copy import deepcopy
            request_user = deepcopy(getattr(request.user, '__dict__', {}))
            if isinstance(request.user, str):
                request_user["user_id"] = request.user
            for each_key in pop_fields:
                if each_key in request_user:
                    request_user.pop(each_key)
            for each_key, value in list(request_user.items()):
                from datetime import datetime, date
                if isinstance(value, datetime) or isinstance(value, date):
                    request_user[each_key] = str(value)

        from copy import deepcopy
        request_data = deepcopy(getattr(request, '_body', None))
        from rest_framework.exceptions import ParseError
        if request_data is not None:
            try:
                request_data = json.loads(request_data)
                if "clientKeyDetailsId" in request_data:
                    request_data = request_data["data"]
                    from django_swagger_utils.drf_server.utils.decorator.\
                        drf_json_parser import drf_json_parser
                    request_data = drf_json_parser(request_data)
            except (ValueError, KeyError, TypeError, ParseError) as err:
                print(err)
                pass

        return {
            "request_id": request.id,
            "user": request_user,
            "basic_info": request_info,
            "meta": request_meta_info,
            "processed_request_data": self.mask_sensitive_info(request_data)
        }

    def process_view(self, request, view_func, view_args, view_kwargs):

        print('This is call to process_view')
        # source:
        # get number of db queries before we do anything
        n = len(connection.queries)

        # time the view
        start = time()
        try:
            response = view_func(request, *view_args, **view_kwargs)
        except Exception as exp:
            self.process_exception(request, exp)
            raise

        total_time = time() - start

        # compute the db time for the queries just run
        db_queries = len(connection.queries) - n
        if db_queries:
            db_time = reduce(add, [float(q['time'])
                                   for q in connection.queries[n:]])
        else:
            db_time = 0.0

        # and backout python time
        python_time = total_time - db_time

        stats = {
            "total_time": total_time,
            "python_time": python_time,
            "db_time": db_time,
            "db_queries": db_queries,
            "request": self._get_request(request),
            "response": self._get_response(response)
        }

        from django.conf import settings
        log_api_url_prefix = getattr(settings, 'LOG_API_URL_PREFIX', ["/api"])

        path_matches = list(set([each for each in log_api_url_prefix if
                                 stats['request']['basic_info'][
                                     'path_info'].startswith(each)]))

        import json
        log_string = json.dumps(stats, indent=4)
        if path_matches:
            if response.status_code is not 200:
                logger_non_200.debug(log_string)
            else:
                logger_200.debug(log_string)
        else:
            logger_non_api.debug(log_string)
        return response

    def _get_response(self, response):
        from django.http import HttpResponse
        from django.http import FileResponse

        if isinstance(response, HttpResponse):
            result = response._container[0].decode('utf-8')
        elif isinstance(response, FileResponse):
            result = ''
        else:
            result = response.data
        return {
            "status_code": response.status_code,
            "headers": response._headers,
            "cookies": response.cookies,
            "response_data": self.mask_sensitive_info(result)
        }

    def process_exception(self, request, exception):
        stats = {
            "log_type": "APILog",
            "request": self._get_request(request),
        }
        import json
        logger_non_200.debug(json.dumps(stats, indent=4))
        return None

    def mask_sensitive_info(self, data):
        keys_to_mask = [
            "access_token",
            "code",
            "phone_number",
            "password",
            "refresh_token"
        ]

        from copy import deepcopy
        data_copy = deepcopy(data)

        try:
            data_copy = json.loads(data_copy)
        except (ValueError, TypeError):
            pass

        if isinstance(data_copy, list):
            new_list = []
            for item in data_copy:
                new_list.append(self.mask_sensitive_info(item))
            return new_list

        elif isinstance(data_copy, dict):
            result_dict = {}
            for key in data_copy:
                value = data_copy[key]
                if isinstance(value, dict) or isinstance(value, list):
                    value = self.mask_sensitive_info(value)

                if key in keys_to_mask:
                    continue
                result_dict[key] = value
            return result_dict
        return data_copy
