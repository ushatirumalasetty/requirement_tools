import logging

from ib_common import local

try:
    from django.utils.deprecation import MiddlewareMixin
except ImportError:
    MiddlewareMixin = object

logger = logging.getLogger(__name__)


class LogFiltersMiddleware(MiddlewareMixin):
    """
    customer log filters related middleware


    settings.py

    MIDDLEWARE.insert(0, 'ib_common.logger.log_filters_middleware.LogFiltersMiddleware')

    """

    def process_request(self, request):
        user_id = "GUEST"
        lambda_context = request.META.get("lambda.context")
        aws_request_id = ""
        if lambda_context is not None:
            aws_request_id = getattr(lambda_context, 'aws_request_id', '')

        local.aws_request_id = aws_request_id
        local.user_id = user_id
        request.user_id = user_id
        local.path_info = getattr(request, 'path_info', '/')

    def process_response(self, request, response):
        try:
            del local.request_id
            del local.path_info
            del local.aws_request_id
        except AttributeError:
            pass

        return response
