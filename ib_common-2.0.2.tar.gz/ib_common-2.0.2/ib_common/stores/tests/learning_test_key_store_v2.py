import os
from django.test import TestCase


class TestKeyStoreV2(TestCase):
    AWS_KEY_STORAGE_BUCKET_NAME = os.environ.get(
        'AWS_KEY_STORAGE_BUCKET_NAME',
        'keystore-s3-bucket'
    )
    AWS_KEY_STORE_S3_REGION_NAME = os.environ.get(
        'AWS_KEY_STORE_S3_REGION_NAME', 'ap-south-1'
    )
    STAGE = os.environ.get("STAGE", "local")

    def test_key_store_v2(self):
        from ib_common.stores.key_store_v2 import KeyStoreV2

        KeyStoreV2.STAGE = self.STAGE
        KeyStoreV2.S3_REGION = self.AWS_KEY_STORE_S3_REGION_NAME
        KeyStoreV2.S3_BUCKET_NAME = self.AWS_KEY_STORAGE_BUCKET_NAME

        key='TOURNAMENT_NAMES'
        value = ['FREE', 'NEW', 'LIVE']

        KeyStoreV2.set_value(key=key, value=value)

        output_value = KeyStoreV2.get_value(key=key)

        self.assertEqual(value, output_value)
