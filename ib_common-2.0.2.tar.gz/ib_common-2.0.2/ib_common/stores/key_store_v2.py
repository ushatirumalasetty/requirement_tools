import os
import logging

LOGGER = logging.getLogger('ib-common')


class DoesNotExist(Exception):
    pass


class KeyStoreV2(object):
    S3_BUCKET_NAME = os.environ.get('AWS_KEY_STORAGE_BUCKET_NAME')
    S3_REGION = os.environ.get('AWS_KEY_STORE_S3_REGION_NAME')
    STAGE = os.environ.get('STAGE')

    @classmethod
    def set_value(cls, key, value):
        cls._push_to_s3(key=key, value=value)

    @classmethod
    def get_value(cls, key):
        value = cls._fetch_from_s3(key=key)
        return value

    @classmethod
    def _push_to_s3(cls, key, value):
        import boto3
        from botocore.client import Config

        bucket_name = cls.S3_BUCKET_NAME
        if not cls._check_if_bucket_exists(bucket_name=bucket_name):
            raise DoesNotExist("S3 Bucket doesnot exist")

        s3_client = boto3.client(
            's3',
            region_name=cls.S3_REGION,
            config=Config(signature_version='s3v4')
        )

        s3_client.put_object(
            Body=value,
            Bucket=bucket_name,
            Key=cls._get_key_name(key=key)
        )

    @classmethod
    def _fetch_from_s3(cls, key):
        import boto3
        from botocore.client import Config
        s3 = boto3.client(
            's3',
            region_name=cls.S3_REGION,
            config=Config(signature_version='s3v4')
        )

        try:
            response = s3.get_object(
                Bucket=cls.S3_BUCKET_NAME,
                Key=cls._get_key_name(key)
            )
        except Exception as err:
            LOGGER.error('{}'.format(err))
            return None

        data = response['Body'].read().decode('utf-8')

        return data

    @classmethod
    def _check_if_bucket_exists(cls, bucket_name):
        import boto3
        import botocore
        s3 = boto3.resource('s3')
        exists = True
        try:
            s3.meta.client.head_bucket(Bucket=bucket_name)
        except botocore.exceptions.ClientError as e:
            # If a client error is thrown, then check that it was a 404 error.
            # If it was a 404 error, then the bucket does not exist.
            error_code = e.response['Error']['Code']
            if error_code == '404':
                exists = False
        return exists

    @classmethod
    def _get_key_name(cls, key):
        paths = "{0}_{1}".format(cls.STAGE, 'key_store')
        paths = paths.split('_')
        paths.append(key)
        complete_key = "/".join(paths)

        return complete_key
