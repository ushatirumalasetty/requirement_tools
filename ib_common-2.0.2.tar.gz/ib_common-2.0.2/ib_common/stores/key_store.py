import logging

from django.conf import settings
from redisco import models

LOGGER = logging.getLogger('ib-common')


class DoesNotExist(Exception):
    pass


try:
    STORE_CONFIG = getattr(settings, 'STORE_CONFIG', {})
    VALUE_MAX_LENGTH = int(STORE_CONFIG.get(
        'KeyStore', {}).get('VALUE_MAX_LENGTH', 3000))
except ValueError:
    VALUE_MAX_LENGTH = 3000


from deprecated import deprecated


@deprecated(
    'This class is deprecated. Use key_store_v2 instead')
class KeyStore(models.Model):
    key_name = models.CharField()
    value = models.CharField(max_length=VALUE_MAX_LENGTH)

    DoesNotExist = DoesNotExist

    class Meta(object):
        STORE_CONFIG = getattr(settings, 'STORE_CONFIG', {})
        store_config = STORE_CONFIG.get('KeyStore', {})

        key = "{0}_{1}_{2}".format(
            store_config.get('NAMESPACE', 'ks'),
            settings.STAGE.lower(),
            'key_store'
        )

    def _convert_to_dict(self):
        return {
            'key_name': self.key_name,
            'value': self.value
        }

    @classmethod
    def _get_key_name(cls, key):
        paths = cls.Meta.key.split('_')
        paths.append(key)
        complete_key = "/".join(paths)
        return complete_key

    @classmethod
    def _get_bucket_name(cls):
        return settings.AWS_KEY_STORAGE_BUCKET_NAME

    @classmethod
    def check_if_bucket_exists(cls, bucket_name):
        import boto3
        import botocore
        s3 = boto3.resource('s3')
        exists = True
        try:
            s3.meta.client.head_bucket(Bucket=bucket_name)
        except botocore.exceptions.ClientError as e:
            # If a client error is thrown, then check that it was a 404 error.
            # If it was a 404 error, then the bucket does not exist.
            error_code = e.response['Error']['Code']
            if error_code == '404':
                exists = False
        return exists

    # @classmethod
    # def _fetch_from_redis(cls, key):
    #     key_store_config = STORE_CONFIG.get('KeyStore', {})
    #     disabled_db_stores = key_store_config.get('DISABLED_DB_STORES', [])
    #     if 'REDIS' in disabled_db_stores:
    #         return
    #     obj = cls.objects.filter(key_name=key).first()
    #     return obj

    @classmethod
    def _fetch_from_s3(cls, key):
        import json
        import boto3
        from botocore.client import Config
        bucket_name = cls._get_bucket_name()
        s3 = boto3.client(
            's3',
            region_name=getattr(
                settings, 'AWS_KEY_STORE_S3_REGION_NAME', 'ap-south-1'
            ),
            config=Config(signature_version='s3v4')
        )

        try:
            response = s3.get_object(
                Bucket=bucket_name,
                Key=cls._get_key_name(key)
            )
        except Exception as err:
            LOGGER.error('{}'.format(err))
            return None

        data = response['Body'].read().decode('utf-8')

        json_data = json.loads(data)
        return cls(**json_data)

    # @classmethod
    # def _push_to_redis(cls, key, value):
    #     key_store_config = STORE_CONFIG.get('KeyStore', {})
    #     disabled_db_stores = key_store_config.get('DISABLED_DB_STORES', [])
    #     if 'REDIS' in disabled_db_stores:
    #         return
    #     try:
    #         obj = cls.objects.filter(key_name=key)[0]
    #         obj.value = value
    #     except IndexError:
    #         obj = cls(key_name=key, value=value)
    #     obj.save()
    #     return obj

    @classmethod
    def _push_to_s3(cls, key, value):
        import boto3
        from botocore.client import Config
        from django.conf import settings

        bucket_name = cls._get_bucket_name()
        s3_client = boto3.resource('s3')

        # Creating the bucket if doesn't exist
        if not cls.check_if_bucket_exists(bucket_name=bucket_name):
            s3_client.create_bucket(Bucket=bucket_name)

        s3_client = boto3.client(
            's3',
            region_name=getattr(
                settings, 'AWS_KEY_STORE_S3_REGION_NAME', 'ap-south-1'
            ),
            config=Config(signature_version='s3v4')
        )

        s3_client.put_object(
            Body=value,
            Bucket=bucket_name,
            Key=cls._get_key_name(key)
        )

    @classmethod
    def get_value(cls, key, value=None):
        # obj = cls._fetch_from_redis(key=key)
        # if not obj:
        obj = cls._fetch_from_s3(key=key)
        if not obj:
            return value
        return obj.value

    @classmethod
    def set_value(cls, key, value):
        import json
        # cls._push_to_redis(key=key, value=value)
        obj = cls(key_name=key, value=value)
        cls._push_to_s3(key=key, value=json.dumps(obj._convert_to_dict()))
        return
