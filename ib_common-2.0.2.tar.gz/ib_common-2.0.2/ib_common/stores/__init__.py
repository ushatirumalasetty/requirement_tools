"""
Configuration Needed
    Required Config
        STAGE = ''
        AWS_KEY_STORAGE_BUCKET_NAME = 'some-bucket-name'

        from redisco import connection_setup
        connection_setup(
            host=DEFAULT_REDIS_HOST,
            port=6379,
            db=KEY_STORE_REDIS_DB
        )


    Optional Config:
        STORE_CONFIG = {
            'KeyStore': {
                'NAMESPACE': 'ks', -> default value('ks')
                'VALUE_MAX_LENGTH': 3000 -> default value 3k
            }
        }
        AWS_KEY_STORE_S3_REGION_NAME = '' # default value ap-south-1

    Exceptions:
        If object doesn't exist it raises `ib_common.stores.key_store.DoesNotExist`
"""

from .key_store import KeyStore
from .key_store_v2 import KeyStoreV2

__all__ = [
    'KeyStore', 'KeyStoreV2'
]
