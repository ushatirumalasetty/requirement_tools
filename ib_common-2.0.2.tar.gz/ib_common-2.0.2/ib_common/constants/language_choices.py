from enum import Enum
from .base_enum_class import BaseEnumClass

__author__ = 'vedavidh'


class LanguageEnum(BaseEnumClass, Enum):
    ENGLISH = 'ENGLISH'
    HINDI = 'HINDI'
    TELUGU = 'TELUGU'
    TAMIL = 'TAMIL'
    KANNADA = 'KANNADA'


class Languages(BaseEnumClass, Enum):
    """
    Enum class representing all the languages supported using vernacular
    """
    ENGLISH = 'en'
    HINDI = 'hi'
    TELUGU = 'te'
    TAMIL = 'ta'
    KANNADA = 'kn'
    BENGALI = 'bn'
    MARATHI = 'mr'


LANGUAGE_CHOICES = [(e.value, e.value) for e in LanguageEnum]

LANGUAGES = [e.value for e in LanguageEnum]

DEFAULT_LANGUAGE = LanguageEnum.ENGLISH.value
