from enum import Enum
from .base_enum_class import BaseEnumClass

__author__ = 'kapeed2091'


class MultimediaTypesEnum(BaseEnumClass, Enum):
    """
    This enum is deprecated use ib_common.constants.MultimediaTypeEnum instead.
    """
    TEXT = 'text'
    IMAGE = 'image'
    AUDIO = 'audio'
    VIDEO = 'video'


MULTIMEDIA_TYPE = [(e.value, e.value) for e in MultimediaTypesEnum]

MULTIMEDIA_TYPES_LIST = [e.value for e in MultimediaTypesEnum]
