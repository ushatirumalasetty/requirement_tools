from enum import Enum
from .base_enum_class import BaseEnumClass

__author__ = 'vedavidh'


class ServiceTypesEnum(BaseEnumClass, Enum):
    SERVICE = 'SERVICE'
    LIBRARY = 'LIBRARY'


SERVICE_TYPE_CHOICES = [(e.value, e.value) for e in ServiceTypesEnum]

SERVICE_TYPES = [e.value for e in ServiceTypesEnum]
