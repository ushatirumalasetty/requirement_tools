from enum import Enum
from .base_enum_class import BaseEnumClass

__author__ = 'kapeed2091'


class ContentTypesEnum(BaseEnumClass, Enum):
    TEXT = 'text'
    LATEX = 'latex'


CONTENT_TYPE = [(e.value, e.value) for e in ContentTypesEnum]

CONTENT_TYPES_LIST = [e.value for e in ContentTypesEnum]
