from builtins import str
from django.utils.translation import ugettext_lazy as _

INVALID_MULTIMEDIA_TYPE = str(_("Invalid multimedia type"))
