from builtins import object
__author__ = 'vedavidh'


class BaseEnumClass(object):
    """
    Base utils class for enums
    """

    @classmethod
    def get_list_of_values(cls):
        """
        from enum import Enum
        from ib_common.constants import BaseEnumClass
        class MyEnum(BaseEnumClass, Enum)
            VALUE_ONE = "VALUE_ONE"
            VALUE_TWO = "VALUE_TWO"

        MyEnum.get_list_of_values()
        >> ["VALUE_ONE", "VALUE_TWO"]
        Get list of enum values as list
        :return:
            ["VALUE_ONE", "VALUE_TWO"]
        """
        return [item.value for item in cls]

    @classmethod
    def get_list_of_names(cls):
        """
        from enum import Enum
        from ib_common.constants import BaseEnumClass
        class MyEnum(BaseEnumClass, Enum)
            VALUE_ONE_CONSTANT = "VALUE_ONE"
            VALUE_TWO_CONSTANT = "VALUE_TWO"

        MyEnum.get_list_of_names()
        >> ["VALUE_ONE_CONSTANT", "VALUE_TWO_CONSTANT"]
        Get list of enum names as list
        :return:
            ["VALUE_ONE_CONSTANT", "VALUE_TWO_CONSTANT"]
        """
        return [item.name for item in cls]

    @classmethod
    def get_list_of_tuples(cls):
        """
        from enum import Enum
        from ib_common.constants import BaseEnumClass
        class MyEnum(BaseEnumClass, Enum)
            VALUE_ONE = "VALUE_ONE"
            VALUE_TWO = "VALUE_TWO"

        MyEnum.get_list_of_tuples()
        >> [("VALUE_ONE", "VALUE_ONE"), ("VALUE_TWO", "VALUE_TWO")]
        Get list of enum values as list
        :return:
            ["VALUE_ONE", "VALUE_TWO"]
        """
        return [(item.value, item.value) for item in cls]
