from enum import Enum
from .base_enum_class import BaseEnumClass

__author__ = 'kapeed2091'


class MultimediaTypeEnum(BaseEnumClass, Enum):
    """
    This enum is a replacement for ib_common.constants.MultimediaTypesEnum
    """
    AUDIO = "AUDIO"
    VIDEO = "VIDEO"
    IMAGE = "IMAGE"
    THUMBNAIL = "THUMBNAIL"
    TEXT = "TEXT"
    PDF = "PDF"
