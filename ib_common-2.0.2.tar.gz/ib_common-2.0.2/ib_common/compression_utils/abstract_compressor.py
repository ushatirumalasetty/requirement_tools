from builtins import object
from abc import ABCMeta
from abc import abstractmethod
from future.utils import with_metaclass
__author__ = 'vedavidh'


class AbstractCompressor(with_metaclass(ABCMeta, object)):

    def __init__(self, *args, **kwargs):
        pass

    
    @abstractmethod
    def compress_string(self, string_):
        pass

    @abstractmethod
    def compress_file(self, file_name, output_file_name):
        pass

    @abstractmethod
    def decompress_string(self, compressed_string):
        pass

    @abstractmethod
    def decompress_file(self, compressed_file_name, output_file_name):
        pass
