# from django

import logging
from operator import add
from time import time

from django.db import connection
from django.utils.deprecation import MiddlewareMixin
from functools import reduce

logger = logging.getLogger('LogAPIMiddleware')


class LogAPIMiddleware(MiddlewareMixin):
    """
    this is a custom middleware, which will log some info about API

    usage:

    settings.py

    LOGGING['logger'].update(
        {
            'LogAPIMiddleware': {
                'handlers': ['console'],
                'level': 'DEBUG',
                'propagate': False,
            }
        }
    )

    MIDDLEWARE += [
        # api log middleware
        'ib_common.middlewares.log_api_middleware.LogAPIMiddleware'
    ]



    """

    def _get_request(self, request):

        request_keys = ['LANGUAGE_CODE', 'method', 'content_params',
                        'path_info', 'path', 'COOKIES', ]
        request_info = {}
        for each in request_keys:
            request_info[each] = getattr(request, each)
        if 'auth' in request.__dict__:
            request_info['auth'] = str(request.auth)

        meta_keys = [
            'HTTP_AUTHORIZATION',
            'HTTP_REFERER',
            'SERVER_SOFTWARE',
            'UPSTART_EVENTS',
            'SCRIPT_NAME',
            'CONTENT_LENGTH',
            'HTTP_ORIGIN',
            'SERVER_PROTOCOL',
            'HTTP_COOKIE',
            'PATH_INFO',
            'UPSTART_INSTANCE',
            'HTTP_AUTHORITY',
            'HTTP_CACHE_CONTROL',
            'HTTP_HOST',
            'HTTP_ACCEPT',
            'SERVER_NAME',
            'HTTP_ACCEPT_LANGUAGE',
            'REQUEST_METHOD',
            'LANGUAGE',
            'HTTP_USER_AGENT',
            'LANG',
            'HTTP_CONNECTION',
            'HTTP_X_SOURCE',
            'REMOTE_ADDR',
            'CONTENT_TYPE',
            'TZ',
            'REMOTE_HOST',
            'HTTP_ACCEPT_ENCODING'
        ]

        request_meta_info = {}
        for each_key in meta_keys:
            if each_key in request.META:
                request_meta_info[each_key] = request.META[each_key]

        request_user = {}
        if request.user is not None:
            pop_fields = ['_state', '_password', 'password', '_setupfunc',
                          '_wrapped']
            from copy import deepcopy
            request_user = deepcopy(getattr(request.user, '__dict__', {}))
            if isinstance(request.user, str):
                request_user["user_id"] = request.user
            for each_key in pop_fields:
                if each_key in request_user:
                    request_user.pop(each_key)
            for each_key, value in list(request_user.items()):
                from datetime import datetime, date
                if isinstance(value, datetime) or isinstance(value, date):
                    request_user[each_key] = str(value)

        return {
            "request_id": request.id,
            "user": request_user,
            "basic_info": request_info,
            "meta": request_meta_info,
        }

    def process_view(self, request, view_func, view_args, view_kwargs):

        # source:
        # get number of db queries before we do anything
        n = len(connection.queries)

        # time the view
        start = time()
        try:
            response = view_func(request, *view_args, **view_kwargs)
        except Exception as exp:
            self.process_exception(request, exp)
            raise

        total_time = time() - start

        # compute the db time for the queries just run
        db_queries = len(connection.queries) - n
        if db_queries:
            db_time = reduce(add, [float(q['time'])
                                   for q in connection.queries[n:]])
        else:
            db_time = 0.0

        # and backout python time
        python_time = total_time - db_time
        stats = {
            "log_type": "APILog",
            "total_time": total_time,
            "python_time": python_time,
            "db_time": db_time,
            "db_queries": db_queries,
            "request": self._get_request(request),
            "response": {
                "status_code": response.status_code,
                "headers": response._headers,
                "cookies": response.cookies,
            }
        }
        import json
        logger.debug(json.dumps(stats, indent=4))
        return response

    def process_exception(self, request, exception):
        stats = {
            "log_type": "APILog",
            "request": self._get_request(request),
        }
        import json
        logger.debug(json.dumps(stats, indent=4))
        return None
