# from django

import logging

from django.utils.deprecation import MiddlewareMixin

logger = logging.getLogger('DateTimeMiddleware')


class DatetimeMiddleware(MiddlewareMixin):
    """
    date time middleware

    usage:

    # base.py

    CORS_ALLOW_HEADERS += ['x-tz']
    MIDDLEWARE_CLASSES += ['ib_common.middlewares.datetime_middleware.DatetimeMiddleware',]
    USE_TZ = True

    # zappa settings

    "cors": true # https://github.com/Miserlou/Zappa#enabling-cors
    or
    "cors": {
      "allowed_headers": ["Content-Type", "Cache-Control", "X-Requested-With", "X-Amz-Date", "Authorization", "X-Api-Key", "X-Amz-Security-Token", "x-source", "x-tz"],
      "allowed_methods": ["DELETE", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT"],
      "allowed_origin": "*"
    },

    sending x-tz with valid time zone string
    ex: x-tz: America/Boa_Vista

    from ib_common.date_time_utils.get_current_local_date_time import \
        get_current_local_date_time
    print(get_current_local_date_time())
    from ib_common.date_time_utils.convert_datetime_to_local_string \
        import convert_datetime_to_local_string
    print(convert_datetime_to_local_string(get_current_local_date_time()))
    from django.utils import timezone
    print(timezone.now())
    print(timezone.get_current_timezone())

    """

    def process_request(self, request):
        headers = request.META
        tz = headers.get("HTTP_X_TZ")
        import pytz
        if tz in pytz.all_timezones:
            tz_obj = pytz.timezone(tz)
            from django.utils import timezone
            timezone.activate(tz_obj)
            print(timezone.get_current_timezone())
            print(tz_obj)

    def process_response(self, request, response):
        from django.utils import timezone
        timezone.deactivate()
        return response
