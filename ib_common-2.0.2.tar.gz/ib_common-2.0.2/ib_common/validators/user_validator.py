__author__ = 'vedavidh'

from django.core.exceptions import ValidationError


class UserValidator(object):
    """
    Validations for user_id / contact_id or any field that refers to users pk

    """
    USER_ID_MAX_LENGTH = 128

    @classmethod
    def validate_user_pk_length(cls, value):
        """
        Validate if user_pk is less than equal to USER_ID_MAX_LENGTH or not
        :param value: user_pk
        :raises:
            :raise ValidationError:
        """
        if len(value) > cls.USER_ID_MAX_LENGTH:
            msg = 'User PK length should be less that {length}' \
                .format(length=cls.USER_ID_MAX_LENGTH)
            raise ValidationError(msg)

    @classmethod
    def check_for_empty_string(cls, value):
        """
        Validate if user_pk is empty or not
        :param value: user_pk
        :raises:
            :raise ValidationError:
        """
        if not value:
            raise ValidationError('Cannot have empty of null value')


validate_user_pk_length = UserValidator.validate_user_pk_length
check_for_empty_string = UserValidator.check_for_empty_string
