from builtins import object
__author__ = 'vedavidh'
from django.core.exceptions import ValidationError

from ib_common.constants.multimedia_type_enum import MultimediaTypeEnum


class MultimediaValidators(object):
    """
    A validator class for multimedia model fields
    """
    MAX_URL_LENGTH = 2000
    MAX_MULTIMEDIA_TYPE_LENGTH = 100
    DEFAULT_MULTIMEDIA_TYPE = MultimediaTypeEnum.TEXT.value

    @staticmethod
    def validate_multimedia_type(value):
        if value not in MultimediaTypeEnum.get_list_of_values():
            from ib_common.constants.exception_messages import \
                INVALID_MULTIMEDIA_TYPE
            raise ValidationError(INVALID_MULTIMEDIA_TYPE)


validate_multimedia_type = MultimediaValidators.validate_multimedia_type
