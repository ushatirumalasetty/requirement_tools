from builtins import object
__author__ = 'vedavidh'


class BaseAdapterClass(object):
    def __init__(self, user, access_token, source=''):
        self.user = user
        self.access_token = access_token
        self.source = source

    @staticmethod
    def execute(method, *args, **kwargs):
        response = method(*args, **kwargs)
        from django_swagger_utils.drf_server.utils.server_gen.mock_response import unwrap_response_dict
        response = unwrap_response_dict(response)
        return response
