from builtins import object
from django.db import models

from ib_common.models.abstract_date_time_model import AbstractDateTimeModel
from ib_common.validators.multimedia_validators import MultimediaValidators
from ib_common.validators.multimedia_validators import validate_multimedia_type
from ib_common.vernacular_utils.vernacular_utilities_class import \
    VernacularUtilitiesClass

__author__ = 'kapeed2091'


class AbstractMultimediaModel(AbstractDateTimeModel, VernacularUtilitiesClass):
    """
    AbstractMultimedia model replacement for existing
    ib_common.abstract_multimedia_model.AbstractMultimediaModel

    :Attributes:
        _multimedia_type: Represents the type of multimedia, value should be
    one of ib_common.constants.multimedia_type_enum.MultimediaTypeEnum
        _multimedia: Represent the url of multimedia.
        _multimedia_thumbnail: Represents the url of multimedia thumbnail.
    """
    _multimedia_type = models.CharField(
        null=True, blank=True,
        max_length=MultimediaValidators.MAX_MULTIMEDIA_TYPE_LENGTH,
        default=MultimediaValidators.DEFAULT_MULTIMEDIA_TYPE,
        validators=[validate_multimedia_type])

    _multimedia = models.URLField(
        null=True, blank=True,
        max_length=MultimediaValidators.MAX_URL_LENGTH)

    _multimedia_thumbnail = models.URLField(
        null=True, blank=True,
        max_length=MultimediaValidators.MAX_URL_LENGTH)

    class Meta(object):
        abstract = True

    @property
    def multimedia_type(self):
        """
        Represent the multimedia_type of current vernacular object
        :return: string
        """
        return self._i_multimedia_type

    @property
    def multimedia(self):
        """
        Represent the multimedia of current vernacular object
        :return: string
        multimedia url
        """
        return self._i_multimedia

    @property
    def multimedia_thumbnail(self):
        """
        Represent the multimedia_thumbnail of current vernacular object
        :return: string
        multimedia_thumbnail url
        """
        return self._i_multimedia_thumbnail
