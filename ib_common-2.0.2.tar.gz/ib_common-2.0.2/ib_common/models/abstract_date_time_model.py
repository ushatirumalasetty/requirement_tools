from builtins import object
from django.db import models
from ib_common.db_utilities import CommonCustomManager


class AbstractDateTimeModel(models.Model):
    """
    from ib_common.models import AbstractDateTimeModel

    def validate_field_1(value):
        print('Validating field_1') # print statement is just for explanation
        ...

    def validate_field_2_for_null(value):
        print('Validating field_2 for null') # print statement is just for
                                               explanation
        ...

    def validate_field_2_for_format(value):
        print('Validating field_2 for format') # print statement is just for
                                                explanation
        ...

    class MyModel(AbstractDateTimeModel):
        field_1 = models.CharField(validators=[validate_field_1])
        field_2 = models.CharField(validators=[validate_field_2_for_null,
                                               validate_field_2_for_format])
        .... # Fields with custom field validators


    obj = MyModel(...)
    obj.save() # Will call all the field validators
    >> Validating field_1
    >> Validating field_2 for null
    >> Validating field_2 for format

    obj = MyModel(...)
    MyModel.objects.bulk_create([obj]) # Will call all the field validators
    >> Validating field_1
    >> Validating field_2 for null
    >> Validating field_2 for format

    With custom managers

    from ib_common.db_utilities import CommonCustomQuerySet
    class MyQuerySet(CommonCustomQuerySet):

        # If overriding bulk_create make sure you call parent definition/
        call
        def bulk_create(*args, **kwargs):
            ... # Custom code

            super(MyQuerySet, self).bulk_create(*args, **kwargs) #
            ... # Custom code

    from ib_common.db_utilities import CommonCustomManager
    class MyManager(CommonCustomManager):
        def get_queryset(self):
            return super(MyManager, self).get_queryset().filter(
                is_deleted=False)

    class MyModel(AbstractDateTimeModel):
        field_1 = models.CharField(validators=[validate_field_1])
        field_2 = models.CharField(validators=[validate_field_2_for_null,
                                               validate_field_2_for_format])
        .... # Fields with custom field validators

        objects = MyManager()

    obj = MyModel(...)
    obj.save() # Will call all the field validators
    >> Validating field_1
    >> Validating field_2 for null
    >> Validating field_2 for format

    obj = MyModel(...)
    MyModel.objects.bulk_create([obj]) # Will call all the field validators
    >> Validating field_1
    >> Validating field_2 for null
    >> Validating field_2 for format

    """
    creation_datetime = models.DateTimeField(auto_now_add=True)
    last_update_datetime = models.DateTimeField(auto_now=True)

    objects = CommonCustomManager()

    class Meta(object):
        abstract = True

    def custom_full_clean(self, exclude=None):
        exclude_fks = [field.name for field in self._meta.fields
                       if isinstance(field, models.ForeignKey)]
        if exclude:
            exclude += exclude_fks
        else:
            exclude = exclude_fks
        self.clean_fields(exclude=exclude)
        self.clean()

    def save(self, *args, **kwargs):
        self.custom_full_clean()
        super(AbstractDateTimeModel, self).save(*args, **kwargs)

    @classmethod
    def bulk_save_or_update(cls, objs):
        objs_for_update = [obj for obj in objs if obj.id]
        objs_to_create = [obj for obj in objs if not obj.id]

        cls.objects.bulk_create(objs_to_create)

        from ib_common.db_utilities.bulk_update import bulk_update
        bulk_update(objs_for_update)
