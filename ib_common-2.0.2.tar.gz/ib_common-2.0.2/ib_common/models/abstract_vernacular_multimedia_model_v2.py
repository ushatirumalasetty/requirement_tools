from builtins import object
from django.db import models

from ib_common.models.abstract_language_model import AbstractLanguageModel
from ib_common.validators.multimedia_validators import MultimediaValidators
from ib_common.validators.multimedia_validators import validate_multimedia_type


class AbstractVernacularMultimediaModel(AbstractLanguageModel):
    """
    AbstractMultimedia model replacement for existing
    ib_common.abstract_multimedia_model.AbstractMultimediaModel

    :Attributes:
        _multimedia_type: Represents the type of multimedia, value should be
    one of ib_common.constants.multimedia_type_enum.MultimediaTypeEnum
        _multimedia: Represent the url of multimedia.
        _multimedia_thumbnail: Represents the url of multimedia thumbnail.
    """
    v_multimedia_type = models.CharField(
        null=True, blank=True,
        max_length=MultimediaValidators.MAX_MULTIMEDIA_TYPE_LENGTH,
        default=MultimediaValidators.DEFAULT_MULTIMEDIA_TYPE,
        validators=[validate_multimedia_type])

    v_multimedia = models.URLField(
        null=True, blank=True,
        max_length=MultimediaValidators.MAX_URL_LENGTH)

    v_multimedia_thumbnail = models.URLField(
        null=True, blank=True,
        max_length=MultimediaValidators.MAX_URL_LENGTH)

    class Meta(object):
        abstract = True
