from future import standard_library
standard_library.install_aliases()
from builtins import str
__author__ = 'kapeed2091'


def get_url_decoded_content(content):
    import urllib.request, urllib.parse, urllib.error
    content = str(urllib.parse.unquote(content).decode('utf8'))
    return content
