__author__ = 'vedavidh'


class abstractclassmethod(classmethod):

    __isabstractmethod__ = True

    def __init__(self, func):
        func.__isabstractmethod__ = True
        super(abstractclassmethod, self).__init__(func)
