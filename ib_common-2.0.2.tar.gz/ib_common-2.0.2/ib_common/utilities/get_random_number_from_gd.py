from __future__ import division
from past.utils import old_div
def get_random_number_from_gd(min_value, max_value, mean_value,
                              standard_deviation=None):
    if min_value == max_value:
        return min_value

    x = 0.0
    if standard_deviation is None:
        standard_deviation = (max_value-min_value) / 6.0
    while x < min_value or x > max_value:
        x = get_random_number_from_mean_and_standard_deviation(
            mean_value, standard_deviation)

    return x


def get_random_number_from_mean_and_standard_deviation(
        mean_value, standard_deviation):
    return mean_value + get_random_number() * standard_deviation


def get_random_number():
    import random
    from math import sqrt, log
    s = 0

    while s >= 1 or s == 0:
        v1 = (2.0 * random.randint(0, 1000)) / 1000.0 - 1.0
        v2 = (2.0 * random.randint(0, 1000)) / 1000.0 - 1.0

        s = v1 * v1 + v2 * v2

    s = sqrt(old_div((-2 * log(s)), s))
    return v1 * s
