from builtins import range
__author__ = 'anush0247'


def generate_id(size):
    import string
    import random
    chars = string.ascii_uppercase.replace('I', '').replace('O', '').replace('L', '') + string.digits.replace('0', '').replace('1', '')
    return ''.join(random.choice(chars) for _ in range(size))
