def get_masked_name(name, username):
    from ib_common.utilities.is_null_or_empty import is_null_or_empty
    if is_null_or_empty(name):
        name = username
        name_list = name.split('@')
        length = len(name_list[0])
        to_replace = name_list[0][2:length]
        replace_with = '*'*(len(to_replace))
        name_list[0] = name_list[0].replace(to_replace, replace_with)
        name = '@'.join(name_list)
    return name
