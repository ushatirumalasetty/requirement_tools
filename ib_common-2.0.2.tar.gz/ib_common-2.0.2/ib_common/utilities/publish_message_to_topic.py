def publish_message_to_topic(topic_name, payload):
    import os
    import json
    import boto3
    from django.conf import settings

    if settings.STAGE == 'local':
        return

    data_client = boto3.client(
        'iot-data', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
        region_name=os.environ.get('AWS_IOT_REGION', settings.AWS_IOT_REGION))

    response = data_client.publish(topic=topic_name, qos=1,
                                   payload=json.dumps(payload))

    return response
