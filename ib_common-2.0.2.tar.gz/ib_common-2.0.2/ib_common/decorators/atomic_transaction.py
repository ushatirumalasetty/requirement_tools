"""
Created on 2019-08-07

@author: revanth
"""
from django.db import transaction


def atomic_transaction(using=None, savepoint=True):

    def inner_dec(func):
        def dec_func(*args, **kwargs):

            with transaction.atomic(using=using, savepoint=savepoint):
                func(*args, **kwargs)

        return dec_func
    return inner_dec
