"""
Created on 11/07/17

@author: revanth
"""



def execution_time(function_name=''):
    """

    :return:
    """

    def decorator(function):
        """

        :param function:
        :return:
        """

        def handler(*args, **kwargs):
            from time import time
            start_time = time()
            return_value = function(*args, **kwargs)
            end_time = time()
            total_time = end_time - start_time

            import logging
            from django.conf import settings
            if not settings.configured:
                settings.configure()
            logger_name = getattr(settings, 'LOGGER_NAME', '')
            if not logger_name:
                logger_name = __name__
            logger = logging.getLogger(logger_name)
            if function_name is None or function_name == '':
                logger.debug("Execution Time: %s, %s" %
                             (function.__name__, total_time))
            else:
                logger.debug("Execution Time: %s, %s" %
                             (function_name, total_time))
            return return_value

        handler.__doc__ = function.__doc__
        return handler

    return decorator
